import base64
import io
import os
import re
from typing import Optional

import streamlit as st
from dotenv import load_dotenv
from openai import OpenAI
from PIL import Image, ImageOps

load_dotenv()

APP_NAME = "VisionAid AI"
NEBIUS_BASE_URL = os.getenv("NEBIUS_BASE_URL", "https://api.tokenfactory.nebius.com/v1/")
VISION_MODEL = os.getenv("VISION_MODEL", "openbmb/MiniCPM-V-4_5")
NVIDIA_MODEL = os.getenv("NVIDIA_MODEL", "nvidia/Nemotron-3_5-Lightning")
MAX_IMAGE_BYTES = 8 * 1024 * 1024

st.set_page_config(page_title=APP_NAME, page_icon="👁️", layout="wide")

st.markdown("""
<style>
  .block-container {max-width: 1150px; padding-top: 2rem; padding-bottom: 3rem;}
  .hero {padding: 1.6rem 1.8rem; border-radius: 20px;
         background: linear-gradient(120deg, rgba(32,91,115,.16), rgba(98,74,160,.13));
         border: 1px solid rgba(128,128,128,.25); margin-bottom: 1.2rem;}
  .hero h1 {margin: 0 0 .35rem 0; font-size: 2.5rem;}
  .muted {opacity: .78;}
  div[data-testid="stMetric"] {border: 1px solid rgba(128,128,128,.25); padding: 1rem; border-radius: 14px;}
  .notice {border-left: 4px solid #d9a441; padding: .7rem 1rem; background: rgba(217,164,65,.09);}
</style>
""", unsafe_allow_html=True)

def get_client() -> OpenAI:
    key = os.getenv("NEBIUS_API_KEY", "").strip()
    if not key:
        raise RuntimeError("NEBIUS_API_KEY is missing. Add it to your .env file or deployment secrets.")
    return OpenAI(api_key=key, base_url=NEBIUS_BASE_URL, timeout=90.0, max_retries=2)

def encode_image(image: Image.Image) -> str:
    image = ImageOps.exif_transpose(image).convert("RGB")
    image.thumbnail((1400, 1400))
    buf = io.BytesIO()
    image.save(buf, format="JPEG", quality=88, optimize=True)
    return base64.b64encode(buf.getvalue()).decode("utf-8")

def ask_vision_model(client: OpenAI, image_data: str) -> str:
    # The vision endpoint must support OpenAI-compatible image_url content.
    result = client.chat.completions.create(
        model=VISION_MODEL,
        temperature=0.2,
        max_tokens=500,
        messages=[
            {
                "role": "system",
                "content": (
                    "You are a careful visual analysis assistant. Describe only visible evidence. "
                    "Do not identify people or infer sensitive traits. Do not claim certainty about "
                    "distances, danger, or safety from a single image."
                ),
            },
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": (
                            "Analyze this image for an accessibility assistant. List the main visible "
                            "objects, where they appear relative to each other (left, right, foreground, "
                            "background), visible pathways or obstacles, and important uncertainty. "
                            "Use concise bullet points. Do not invent details."
                        ),
                    },
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:image/jpeg;base64,{image_data}"},
                    },
                ],
            },
        ],
    )
    return (result.choices[0].message.content or "").strip()

def ask_nemotron(client: OpenAI, visual_notes: str, user_focus: str) -> str:
    focus = user_focus.strip() or "Give a concise general description of the scene."
    result = client.chat.completions.create(
        model=NVIDIA_MODEL,
        temperature=0.25,
        max_tokens=650,
        messages=[
            {
                "role": "system",
                "content": (
                    "You are VisionAid AI, an accessibility-oriented scene explanation assistant. "
                    "Use only the supplied visual notes. Never add objects or facts not supported by "
                    "those notes. Clearly mark uncertainty. Do not claim that a path is safe or that "
                    "an obstacle is a specific distance away unless that was measured. This is an aid, "
                    "not a replacement for a cane, guide dog, or human assistance."
                ),
            },
            {
                "role": "user",
                "content": (
                    f"User's focus: {focus}\n\n"
                    f"Visual model notes:\n{visual_notes}\n\n"
                    "Return these sections with short headings:\n"
                    "1. Scene summary (1-3 sentences)\n"
                    "2. Objects and relative positions (bullets)\n"
                    "3. Things to pay attention to (only evidence-based; state uncertainty)\n"
                    "4. Confidence and limitations (one sentence)"
                ),
            },
        ],
    )
    return (result.choices[0].message.content or "").strip()

def speak_text(text: str) -> None:
    # Browser-native speech synthesis; no audio is sent to a third-party TTS provider.
    safe_text = re.sub(r"[\r\n]+", ". ", text)
    safe_text = safe_text.replace("\\", "\\\\").replace("`", "\\`").replace("$", "\\$")
    st.components.v1.html(
        f"""
        <button id="speak" style="padding:10px 16px;border-radius:10px;border:1px solid #888;cursor:pointer;">
          🔊 Read description aloud
        </button>
        <button id="stop" style="padding:10px 16px;margin-left:8px;border-radius:10px;border:1px solid #888;cursor:pointer;">
          Stop
        </button>
        <script>
          const text = `{safe_text}`;
          document.getElementById('speak').onclick = () => {{
            if (!('speechSynthesis' in window)) {{ alert('Speech is not supported by this browser.'); return; }}
            window.speechSynthesis.cancel();
            const utterance = new SpeechSynthesisUtterance(text);
            utterance.rate = 0.95;
            window.speechSynthesis.speak(utterance);
          }};
          document.getElementById('stop').onclick = () => window.speechSynthesis.cancel();
        </script>
        """,
        height=58,
    )

st.markdown("""
<div class="hero">
  <h1>👁️ VisionAid AI</h1>
  <div class="muted">Understand the scene. Hear what matters. Built for more accessible visual information.</div>
</div>
""", unsafe_allow_html=True)

st.write(
    "Upload a photo to get an AI-generated description of visible objects, their relative positions, "
    "and details that may deserve attention."
)

with st.sidebar:
    st.header("About this demo")
    st.markdown(
        "- **Vision model:** describes the uploaded image.\n"
        "- **NVIDIA Nemotron:** organizes the visual notes into a helpful explanation.\n"
        "- **Speech:** uses your browser's built-in text-to-speech."
    )
    st.divider()
    st.caption("Privacy: the selected image is sent to the configured Nebius Token Factory inference endpoint for analysis. Do not upload sensitive images.")
    st.caption("Safety: AI descriptions can be wrong. Do not rely on this prototype as your only mobility or safety aid.")

left, right = st.columns([0.95, 1.05], gap="large")
with left:
    uploaded = st.file_uploader(
        "Choose an image",
        type=["png", "jpg", "jpeg", "webp"],
        help="For best results, use a clear, well-lit photo.",
    )
    focus = st.text_input(
        "What should VisionAid focus on? (optional)",
        placeholder="e.g. objects near the doorway",
    )
    analyze = st.button("✨ Analyze scene", type="primary", use_container_width=True, disabled=uploaded is None)

    if uploaded is not None:
        raw = uploaded.getvalue()
        if len(raw) > MAX_IMAGE_BYTES:
            st.error("This image is larger than 8 MB. Please choose a smaller file.")
            uploaded = None
        else:
            try:
                preview = Image.open(io.BytesIO(raw))
                preview = ImageOps.exif_transpose(preview)
                st.image(preview, caption="Image selected for analysis", use_container_width=True)
            except Exception:
                st.error("That file could not be opened as an image.")
                uploaded = None

with right:
    st.subheader("Scene understanding")
    if analyze and uploaded is not None:
        try:
            image = Image.open(io.BytesIO(uploaded.getvalue()))
            image_data = encode_image(image)
            client = get_client()

            with st.status("Analyzing the image…", expanded=True) as status:
                st.write("Step 1 of 2 · Interpreting visible objects and layout")
                visual_notes = ask_vision_model(client, image_data)
                if not visual_notes:
                    raise RuntimeError("The vision model returned an empty response.")
                st.write("Step 2 of 2 · NVIDIA Nemotron is preparing an accessible summary")
                description = ask_nemotron(client, visual_notes, focus)
                if not description:
                    raise RuntimeError("Nemotron returned an empty response.")
                status.update(label="Analysis complete", state="complete", expanded=False)

            st.markdown(description)
            speak_text(description)
            with st.expander("View visual model notes"):
                st.markdown(visual_notes)
            st.download_button(
                "Download description",
                data=description,
                file_name="visionaid-description.txt",
                mime="text/plain",
            )
        except Exception as exc:
            st.error("VisionAid couldn't complete the analysis.")
            st.markdown(
                "Check that your API key is valid, both model IDs are available to your Nebius account, "
                "and the configured vision model supports image inputs."
            )
            with st.expander("Technical details"):
                st.code(str(exc))
    else:
        st.info("Your scene description will appear here after you select an image and click **Analyze scene**.")
        st.markdown("""
        **Example output**
        - Scene summary
        - Visible objects and relative positions
        - Details that may deserve attention
        - Confidence and limitations
        """)

st.divider()
st.caption("VisionAid AI is a prototype for accessibility research. It may miss objects or describe scenes incorrectly.")
