# VisionAid AI

**An AI-powered visual assistant that turns an image into a concise scene description.**

VisionAid AI is a hackathon prototype for improving access to visual information. It accepts an uploaded image, asks a vision-capable model to describe visible objects and relative positions, and uses NVIDIA Nemotron through Nebius Token Factory to turn those notes into an accessibility-oriented summary. It can also read the result aloud using the browser's built-in speech synthesis.

## Features

- Image upload (PNG, JPG, JPEG, WEBP)
- Image interpretation and scene notes
- NVIDIA Nemotron-generated scene summary
- Optional focus prompt
- Browser-based text-to-speech
- Downloadable text description
- Clear limitations and privacy messaging

## Architecture

1. **Streamlit UI** accepts the image.
2. **Vision model on Nebius Token Factory** describes objects and layout.
3. **NVIDIA Nemotron on Nebius Token Factory** structures the notes into a readable scene explanation.
4. **Browser speech synthesis** optionally reads the result aloud.

The project uses an OpenAI-compatible Token Factory API. Confirm that the selected vision model is available to your account and supports image inputs. Model availability can vary by account and catalog.

## Requirements

- Python 3.10+
- A Nebius Token Factory API key
- Access to a vision-capable model and an NVIDIA open-source Nemotron model in your Token Factory catalog

## Run locally

### Windows PowerShell

```powershell
cd visionaid-ai
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
notepad .env
```

Add your API key in `.env`, then run:

```powershell
streamlit run app.py
```

### macOS / Linux

```bash
cd visionaid-ai
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Edit .env and add your API key
streamlit run app.py
```

The app normally opens at `http://localhost:8501`.

## Configure models

In `.env`, set:

```dotenv
NEBIUS_API_KEY=your_key_here
NEBIUS_BASE_URL=https://api.tokenfactory.nebius.com/v1/
VISION_MODEL=openbmb/MiniCPM-V-4_5
NVIDIA_MODEL=nvidia/Nemotron-3_5-Lightning
```

If a model is unavailable or does not accept images, open the Token Factory model catalog and replace `VISION_MODEL` with an available vision model ID that supports OpenAI-compatible image input. Keep `NVIDIA_MODEL` set to an available NVIDIA open-source model. The app makes runtime calls to Token Factory for both model steps.

## Deploy

You can deploy the Streamlit app to a hosting service that supports Python. Add `NEBIUS_API_KEY`, `NEBIUS_BASE_URL`, `VISION_MODEL`, and `NVIDIA_MODEL` as deployment secrets/environment variables. Do not commit your `.env` file or expose the API key in browser code.

For hackathon compliance, verify that the app is making runtime inference calls to Nebius Token Factory and using an NVIDIA open-source model. Follow the current official rules for demo availability, repository license, and the required public demonstration video.

## Safety and privacy

- Uploaded images are sent to the configured inference provider for processing.
- Do not upload sensitive or private images.
- AI can miss objects, confuse relationships, or produce incorrect descriptions.
- This prototype is not a certified navigation device and must not replace a cane, guide dog, or other established mobility support.

## Hackathon track

Suggested track: **Best Apps and Agents**.

## License

MIT. See [LICENSE](LICENSE).
